package com.sada.walkie

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

private const val RC_MIC = 1
private const val RC_NET = 2

class MainActivity : Activity() {
    private lateinit var radio: Radio
    private lateinit var wv: WebView
    private var hs: WifiManager.LocalOnlyHotspotReservation? = null
    @Volatile private var hsInfo = ""
    @Volatile private var joinState = ""
    private var joinCb: ConnectivityManager.NetworkCallback? = null

    private fun granted(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun hasMic() = granted(Manifest.permission.RECORD_AUDIO)
    private fun netPerm() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES
    else Manifest.permission.ACCESS_FINE_LOCATION

    private fun svc() = Intent(this, WalkieService::class.java)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = Color.parseColor("#F93A3A")
        window.navigationBarColor = Color.parseColor("#B3000D")
        volumeControlStream = AudioManager.STREAM_MUSIC   // أزرار الصوت تتحكم بقوة اللاسلكي
        radio = Radio.get(this)

        wv = WebView(this)
        wv.setBackgroundColor(Color.parseColor("#D4121B"))
        wv.overScrollMode = View.OVER_SCROLL_NEVER
        wv.isVerticalScrollBarEnabled = false
        wv.setOnLongClickListener { true }
        setContentView(wv)
        with(wv.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowContentAccess = false
            setSupportZoom(false)
            textZoom = 100
        }
        wv.addJavascriptInterface(Bridge(), "Android")
        wv.loadUrl("file:///android_asset/index.html")
    }

    override fun onRequestPermissionsResult(rc: Int, perms: Array<out String>, res: IntArray) {
        super.onRequestPermissionsResult(rc, perms, res)
        val ok = when (rc) {
            RC_MIC -> hasMic()
            RC_NET -> granted(netPerm())
            else -> return
        }
        wv.evaluateJavascript("window.onPerm&&window.onPerm($rc,$ok)", null)
    }

    // زر الرجوع: يغلق النافذة المفتوحة، وإلا يُبقي التطبيق يعمل بالخلفية
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        wv.evaluateJavascript(
            "(function(){var s=document.getElementById('sheet');if(s&&!s.hidden){s.hidden=true;return 1}return 0})()"
        ) { r -> if (r != "1") moveTaskToBack(true) }
    }

    override fun onDestroy() {
        if (isFinishing) {
            radio.stop()
            stopService(svc())
            try { hs?.close() } catch (_: Exception) {}
            hs = null
            leaveNetwork()
        }
        super.onDestroy()
    }

    private fun leaveNetwork() {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try { cm.bindProcessToNetwork(null) } catch (_: Exception) {}
        joinCb?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
        joinCb = null
        joinState = ""
    }

    inner class Bridge {
        // ---------- التشغيل ----------
        @JavascriptInterface fun hasMic(): Boolean = this@MainActivity.hasMic()

        @JavascriptInterface fun start(): Boolean {
            if (!this@MainActivity.hasMic()) {
                val list = mutableListOf(Manifest.permission.RECORD_AUDIO)
                if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS))
                    list.add(Manifest.permission.POST_NOTIFICATIONS)
                runOnUiThread { requestPermissions(list.toTypedArray(), RC_MIC) }
                return false
            }
            val ok = radio.start()
            if (ok) runOnUiThread { try { startForegroundService(svc()) } catch (_: Exception) {} }
            return ok
        }

        @JavascriptInterface fun stop() {
            radio.stop()
            runOnUiThread { stopService(svc()) }
        }

        @JavascriptInterface fun running(): Boolean = radio.running
        @JavascriptInterface fun talk(on: Boolean) = radio.talk(on)
        @JavascriptInterface fun peers(): Int = radio.peers()
        @JavascriptInterface fun receiving(): Boolean = System.currentTimeMillis() - radio.lastRx < 500
        @JavascriptInterface fun setChannel(c: Int) { radio.channel = c.coerceIn(1, 8) }
        @JavascriptInterface fun setListen(l: Boolean) { radio.listen = l }

        // ---------- الصوت والشاشة ----------
        @JavascriptInterface fun setBoost(l: Int) { radio.boost = l.coerceIn(0, 3); radio.applyVolume() }
        @JavascriptInterface fun setPhoneAudio(on: Boolean) { radio.phoneAudio = on; radio.applyVolume() }
        @JavascriptInterface fun keepScreen(on: Boolean) = runOnUiThread {
            if (on) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
        @JavascriptInterface fun haptic() = runOnUiThread {
            wv.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
        }

        // ---------- إنشاء هوتسبوت محلي ----------
        @JavascriptInterface fun hotspotStart(): Boolean {
            if (!granted(netPerm())) {
                runOnUiThread { requestPermissions(arrayOf(netPerm()), RC_NET) }
                return false
            }
            hsInfo = ""
            try {
                val wm = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                wm.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                    override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                        hs = r
                        hsInfo = if (Build.VERSION.SDK_INT >= 30) {
                            val c = r.softApConfiguration; "${c.ssid}\n${c.passphrase}"
                        } else {
                            @Suppress("DEPRECATION")
                            val c = r.wifiConfiguration; "${c?.SSID}\n${c?.preSharedKey}"
                        }
                    }
                    override fun onFailed(reason: Int) { hsInfo = "ERR:$reason" }
                }, Handler(Looper.getMainLooper()))
            } catch (e: Exception) { hsInfo = "ERR:" + e.message }
            return true
        }
        @JavascriptInterface fun hotspotInfo(): String = hsInfo
        @JavascriptInterface fun hotspotStop() { try { hs?.close() } catch (_: Exception) {}; hs = null; hsInfo = "" }

        // ---------- الانضمام لهوتسبوت هاتف آخر ----------
        @JavascriptInterface fun join(ssid: String, pass: String): Boolean {
            if (Build.VERSION.SDK_INT < 29) return false
            val spec = WifiNetworkSpecifier.Builder().setSsid(ssid).setWpa2Passphrase(pass).build()
            val req = NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).setNetworkSpecifier(spec).build()
            val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            joinCb?.let { try { cm.unregisterNetworkCallback(it) } catch (_: Exception) {} }
            joinState = "WAIT"
            joinCb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(n: Network) {
                    if (cm.bindProcessToNetwork(n)) {
                        joinState = "OK"
                        if (radio.running) radio.restart()      // إعادة ربط المقبس بالشبكة الجديدة
                    } else joinState = "ERR"
                }
                override fun onUnavailable() { cm.bindProcessToNetwork(null); joinState = "ERR" }
                override fun onLost(n: Network) { cm.bindProcessToNetwork(null); joinState = "ERR" }
            }
            cm.requestNetwork(req, joinCb!!)
            return true
        }
        @JavascriptInterface fun joinState(): String = joinState
        @JavascriptInterface fun leaveNetwork() = this@MainActivity.leaveNetwork()
    }
}
